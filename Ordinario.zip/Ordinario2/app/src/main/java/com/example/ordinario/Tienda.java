package com.example.ordinario;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Tienda extends AppCompatActivity implements View.OnClickListener{
    Button btnagregar,btnEditar, btnEliminar, btnMostrar, btnSalir;
    int id=0;
    Productos u;
    daoProductos dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tienda);

        btnEditar = (Button) findViewById(R.id.btnEditarProductos);
        btnEliminar = (Button) findViewById(R.id.btnEliminarProductos);
        btnMostrar = (Button) findViewById(R.id.btnMostrarProd);
        btnSalir = (Button) findViewById(R.id.btnSalirInicio);
        btnagregar = (Button) findViewById(R.id.btnAgregarProductos);

        btnagregar.setOnClickListener(this);
        btnSalir.setOnClickListener(this);
        btnEditar.setOnClickListener(this);
        btnEliminar.setOnClickListener(this);
        btnMostrar.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnEditarProductos:
                Intent a = new Intent(Tienda.this, EditarProd.class);
                startActivity(a);
                break;
            case R.id.btnMostrarProd:
                Intent c = new Intent(Tienda.this, MostrarProd.class);
                startActivity(c);

                break;
            case R.id.btnAgregarProductos:
                Intent f = new Intent(Tienda.this, RegistrarProd.class);
                startActivity(f);

                break;
            case R.id.btnSalir:
                Intent d = new Intent(Tienda.this, Inicio.class);
                startActivity(d);

                break;

        }
    }
}