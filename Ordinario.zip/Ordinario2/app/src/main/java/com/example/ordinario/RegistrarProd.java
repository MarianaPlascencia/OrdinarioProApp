package com.example.ordinario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistrarProd extends AppCompatActivity implements View.OnClickListener{
    EditText nom,dpt,pre;
    Button regp,canp;
    daoProductos dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registrarprod);
        nom=(EditText)findViewById(R.id.AgrenomProd);
        dpt=(EditText)findViewById(R.id.AgreDepartamento);
        pre=(EditText)findViewById(R.id.AgrePrecio);
        regp=(Button) findViewById(R.id.btnAgreProd);
        canp=(Button) findViewById(R.id.btnAgreCancelar);
        regp.setOnClickListener(this);
        canp.setOnClickListener(this);
        dao=new daoProductos(this);
    }
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnAgreProd:
                Productos u=new Productos();
                u.setNombreP(nom.getText().toString());
                u.setDepartamentoP(dpt.getText().toString());
                u.setPrecioP(pre.getText().toString());
                if (!u.isNull()){
                    Toast.makeText(this, "Campos vacíos", Toast.LENGTH_SHORT).show();
                }else if(dao.insertProducto(u)){
                    Toast.makeText(this, "¡Usuario Agregado!", Toast.LENGTH_SHORT).show();
                    Intent i2=new Intent(RegistrarProd.this, Tienda.class);
                    startActivity(i2);

                }else{
                    Toast.makeText(this, "¡Usuario Repetido!", Toast.LENGTH_SHORT).show();
                }


                break;
            case R.id.btnAgreCancelar:
                Intent i=new Intent(RegistrarProd.this, Tienda.class);
                startActivity(i);
                finish();
                break;


        }


    }
}