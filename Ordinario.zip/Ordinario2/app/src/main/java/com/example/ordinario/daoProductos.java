package com.example.ordinario;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class daoProductos {
    Context c;
    Productos u;
    ArrayList<Productos> lista;
    SQLiteDatabase sql;
    String bd= "BDProductos";
    String tabla="create table if not exists producto(id integer primary key autoincrement, nombre text, dep text, tipo text)";

    public daoProductos(Context c){
        this.c=c;
        sql=c.openOrCreateDatabase(bd,c.MODE_PRIVATE,null);
        sql.execSQL(tabla);
        u=new Productos();
    }
    //nombre dep tipo
    public boolean insertProducto(Productos u){
        if(buscarp(u.getNombreP())==0){
            ContentValues cv=new ContentValues();
            cv.put("nombre",u.getNombreP());
            cv.put("dep",u.getDepartamentoP());
            cv.put("tipo",u.getPrecioP());
            return (sql.insert("producto",null,cv)>0);
        }else{
            return false;
        }
    }
    public int buscarp(String u){
        int x=0;
        lista=selectProductos();
        for (Productos us:lista){
            if (us.getNombreP().equals(u)){
                x++;
            }
        }
        return x;
    }
    public ArrayList<Productos> selectProductos() {
        ArrayList<Productos>lista=new ArrayList<Productos>();
        Cursor cr=sql.rawQuery("select * from producto",null);
        if(cr!=null && cr.moveToFirst()){
            do{
                Productos u=new Productos();
                u.setIdp(cr.getInt(0));
                u.setNombreP(cr.getString(1));
                u.setDepartamentoP(cr.getString(2));
                u.setPrecioP(cr.getString(3));
                lista.add(u);
            }while (cr.moveToNext());
        }
        return lista;
    }
    //Sí se cumple la condicion entrega borra,sino, regresa1
    public boolean logprod(String u) {
        int a = 0;
        Cursor cr = sql.rawQuery("select * from producto", null);
        if (cr != null && cr.moveToFirst()) {
            do {
                if (cr.getString(1).equals(u)) {
                    a++;
                }
            } while (cr.moveToNext());
        }
        return (sql.delete("producto", "nombre=" + u, null) > 0);
    }

    public boolean updateProducto(Productos u){

        ContentValues cv=new ContentValues();
        cv.put("nombre",u.getNombreP());
        cv.put("dep",u.getDepartamentoP());
        cv.put("tipo",u.getPrecioP());
        return (sql.update("producto", cv, "Id" + u.getIdp(), null) > 0);
    }



}
