package com.example.ordinario;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MostrarProd extends AppCompatActivity {
    ListView Lista;
    daoProductos dao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mostrarprod);
        Lista=(ListView)findViewById(R.id.LProductos);
        dao=new daoProductos(this);
        ArrayList<Productos> l=dao.selectProductos();
        ArrayList<String> list=new ArrayList<String>();
        for (Productos u:l) {
            list.add("Producto -> "+u.getNombreP()+" "+ u.getDepartamentoP()+" "+u.getPrecioP());
        }
        ArrayAdapter<String> a=new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1,list);
        Lista.setAdapter(a);
    }
}