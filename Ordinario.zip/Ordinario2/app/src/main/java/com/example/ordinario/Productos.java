package com.example.ordinario;

public class Productos {
    int idp;
    String NombreP, DepartamentoP, PrecioP;

    public Productos() {
    }

    public Productos(String nombreP, String departamentoP, String precioP) {
        NombreP = nombreP;
        DepartamentoP = departamentoP;
        PrecioP = precioP;
    }

    public boolean isNull() {
        if (NombreP.equals("") && DepartamentoP.equals("") && PrecioP.equals("")) {
            return false;
        } else {
            return true;
        }
    }


    @Override
    public String toString() {
        return "Productos{" +
                "idp=" + idp +
                ", NombreP='" + NombreP + '\'' +
                ", DepartamentoP='" + DepartamentoP + '\'' +
                ", PrecioP='" + PrecioP + '\'' +
                '}';
    }

    public int getIdp() {
        return idp;
    }

    public void setIdp(int idp) {
        this.idp = idp;
    }

    public String getNombreP() {
        return NombreP;
    }

    public void setNombreP(String nombreP) {
        NombreP = nombreP;
    }

    public String getDepartamentoP() {
        return DepartamentoP;
    }

    public void setDepartamentoP(String departamentoP) {
        DepartamentoP = departamentoP;
    }

    public String getPrecioP() {
        return PrecioP;
    }

    public void setPrecioP(String precioP) {
        PrecioP = precioP;
    }
}
